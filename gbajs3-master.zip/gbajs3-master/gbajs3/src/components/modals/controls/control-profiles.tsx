import { IconButton, TextField } from '@mui/material';
import { styled } from '@mui/material/styles';
import { useLocalStorage } from '@uidotdev/usehooks';
import { nanoid } from 'nanoid';
import { useState } from 'react';
import { BiTrash, BiEdit, BiSave } from 'react-icons/bi';

import {
  useInitialBoundsContext,
  useLayoutContext
} from '../../../hooks/context.tsx';
import { virtualControlProfilesLocalStorageKey } from '../../controls/consts.tsx';
import { CenteredText, StyledBiPlus } from '../../shared/styled.tsx';

import type { Layouts } from '../../../context/layout/layout-context.tsx';
import type { IconButtonProps } from '@mui/material';
import type { ReactNode } from 'react';

type ControlProfilesProps = {
  id: string;
};

type VirtualControlProfile = {
  id: string;
  name: string;
  active: boolean;
  layouts: Layouts;
};

type VirtualControlProfiles = VirtualControlProfile[];

type StatefulIconButtonProps = {
  condition: boolean;
  truthyIcon: ReactNode;
  falsyIcon: ReactNode;
} & IconButtonProps;

type EditableProfileLoadButtonProps = {
  name: string;
  loadProfile: () => void;
  onSubmit: (name: string) => void;
};

const StyledLi = styled('li')`
  cursor: pointer;
  display: grid;
  grid-template-columns: auto 32px;
  gap: 10px;

  color: ${({ theme }) => theme.blueCharcoal};
  background-color: ${({ theme }) => theme.pureWhite};
  border: 1px solid rgba(0, 0, 0, 0.125);
`;

const ProfilesList = styled('ul')`
  list-style-type: none;
  display: flex;
  flex-direction: column;
  margin: 0;
  padding: 0;

  & > ${StyledLi}:first-of-type {
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
  }

  & > ${StyledLi}:last-child {
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
  }

  & > ${StyledLi}:not(:first-of-type) {
    border-top-width: 0;
  }
`;

const StyledBiTrash = styled(BiTrash)`
  height: 100%;
  width: 20px;
`;

const StyledBiEdit = styled(BiEdit)`
  height: 100%;
  width: 20px;
`;

const StyledBiSave = styled(BiSave)`
  height: 100%;
  width: 20px;
`;

const LoadProfileButton = styled('button')`
  padding: 0.5rem 0.5rem;
  width: 100%;
  color: ${({ theme }) => theme.blueCharcoal};
  background-color: ${({ theme }) => theme.pureWhite};
  border: none;
  text-align: left;
  font-size: 16px;
  height: 32px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;

  &:hover {
    color: ${({ theme }) => theme.darkGrayBlue};
    background-color: ${({ theme }) => theme.aliceBlue1};
  }
`;

const FlexContainer = styled('div')`
  display: flex;
  gap: 10px;
  min-width: 0;
`;

const StatefulIconButton = ({
  condition,
  truthyIcon,
  falsyIcon,
  ...rest
}: StatefulIconButtonProps) => (
  <IconButton sx={{ padding: 0 }} {...rest}>
    {condition ? truthyIcon : falsyIcon}
  </IconButton>
);

const EditableProfileLoadButton = ({
  name,
  loadProfile,
  onSubmit
}: EditableProfileLoadButtonProps) => {
  const [isEditing, setIsEditing] = useState(false);
  const [storedName, setStoredName] = useState(name);

  const submitNameChange = (name?: string) => {
    if (isEditing && name) onSubmit(name);

    setIsEditing((prevState) => !prevState);
  };

  return (
    <FlexContainer>
      {isEditing ? (
        <TextField
          variant="standard"
          sx={{
            width: '100%',
            '& .MuiInputBase-input': {
              paddingLeft: '8px'
            }
          }}
          error={!storedName}
          value={storedName}
          onChange={(e) => {
            setStoredName(e.target.value);
          }}
        />
      ) : (
        <LoadProfileButton onClick={loadProfile}>{name}</LoadProfileButton>
      )}
      <StatefulIconButton
        condition={isEditing}
        truthyIcon={<StyledBiSave />}
        falsyIcon={<StyledBiEdit />}
        aria-label={`${isEditing ? 'Save' : 'Edit'} ${name}'s name`}
        type="submit"
        onClick={() => {
          submitNameChange(storedName);
        }}
      />
    </FlexContainer>
  );
};

export const ControlProfiles = ({ id }: ControlProfilesProps) => {
  const [virtualControlProfiles, setVirtualControlProfiles] = useLocalStorage<
    VirtualControlProfiles | undefined
  >(virtualControlProfilesLocalStorageKey);
  const { layouts, setLayouts } = useLayoutContext();
  const { clearInitialBounds } = useInitialBoundsContext();

  const addProfile = () => {
    setVirtualControlProfiles((prevState) => [
      ...(prevState ?? []),
      {
        id: nanoid(),
        name: `Profile-${(prevState?.length ?? 0) + 1}`,
        layouts: layouts,
        active: true
      }
    ]);
  };

  const loadProfile = (layouts: Layouts) => {
    setLayouts(layouts);
    clearInitialBounds();
  };

  const updateProfile = (id: string, updatedName: string) => {
    setVirtualControlProfiles((prevState) =>
      prevState?.map((profile) => {
        if (profile.id === id)
          return {
            ...profile,
            name: updatedName
          };

        return profile;
      })
    );
  };

  const deleteProfile = (id: string) => {
    setVirtualControlProfiles((prevState) =>
      prevState?.filter((p) => p.id !== id)
    );
  };

  return (
    <>
      <ProfilesList id={id} aria-label="Profiles List">
        {virtualControlProfiles?.map(
          (profile: VirtualControlProfile, idx: number) => (
            <StyledLi key={`${profile.name}_${idx}_action_list_item`}>
              <EditableProfileLoadButton
                name={profile.name}
                loadProfile={() => {
                  loadProfile(profile.layouts);
                }}
                onSubmit={(name) => {
                  updateProfile(profile.id, name);
                }}
              />
              <IconButton
                aria-label={`Delete ${profile.name}`}
                sx={{ padding: 0 }}
                onClick={() => {
                  deleteProfile(profile.id);
                }}
              >
                <StyledBiTrash />
              </IconButton>
            </StyledLi>
          )
        )}
        {!virtualControlProfiles?.length && (
          <li>
            <CenteredText>No control profiles</CenteredText>
          </li>
        )}
      </ProfilesList>
      <IconButton
        aria-label={`Create New Profile`}
        sx={{ padding: 0 }}
        onClick={() => {
          addProfile();
        }}
      >
        <StyledBiPlus />
      </IconButton>
    </>
  );
};
