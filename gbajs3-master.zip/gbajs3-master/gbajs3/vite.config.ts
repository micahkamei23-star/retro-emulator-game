import react from '@vitejs/plugin-react-swc';
import { visualizer } from 'rollup-plugin-visualizer';
// eslint-disable-next-line import/no-unresolved
import { defineConfig, type PluginOption } from 'vite';
import { createHtmlPlugin } from 'vite-plugin-html';
import { VitePWA } from 'vite-plugin-pwa';
import { viteStaticCopy } from 'vite-plugin-static-copy';
// eslint-disable-next-line import/no-unresolved
import { coverageConfigDefaults } from 'vitest/config';

// eslint-disable-next-line import/no-default-export
export default defineConfig(({ mode }) => {
  const withCOIServiceWorker = mode === 'with-coi-serviceworker';

  return {
    base: './',
    plugins: [
      react({
        plugins: [
          [
            '@swc/plugin-emotion',
            {
              // items for component selectors with MUI+SWC
              autoLabel: 'dev-only',
              labelFormat: '[local]',
              importMap: {
                '@mui/material/styles': {
                  styled: {
                    canonicalImport: ['@emotion/styled', 'default'],
                    styledBaseImport: ['@mui/material/styles', 'styled']
                  }
                }
              }
            }
          ]
        ]
      }),
      withCOIServiceWorker
        ? [
            createHtmlPlugin({
              inject: {
                tags: [
                  {
                    tag: 'script',
                    attrs: { src: 'coi-sw.js' },
                    injectTo: 'head-prepend'
                  }
                ]
              }
            })
          ]
        : [],
      VitePWA({
        registerType: 'autoUpdate',
        includeAssets: ['./img/favicon.ico'],
        manifest: {
          name: 'Gbajs3',
          short_name: 'GJ3',
          description: 'GBA emulator online in the Browser',
          theme_color: '#212529',
          background_color: '#212529',
          icons: [
            {
              src: './img/icon-192x192.png',
              sizes: '192x192',
              type: 'image/png'
            },
            {
              src: './img/icon-256x256.png',
              sizes: '256x256',
              type: 'image/png'
            },
            {
              src: './img/icon-384x384.png',
              sizes: '384x384',
              type: 'image/png'
            },
            {
              src: './img/icon-512x512.png',
              sizes: '512x512',
              type: 'image/png'
            },
            {
              src: './img/maskable-icon-192x192.png',
              sizes: '192x192',
              type: 'image/png',
              purpose: 'maskable'
            },
            {
              src: './img/maskable-icon-256x256.png',
              sizes: '256x256',
              type: 'image/png',
              purpose: 'maskable'
            },
            {
              src: './img/maskable-icon-384x384.png',
              sizes: '384x384',
              type: 'image/png',
              purpose: 'maskable'
            },
            {
              src: './img/maskable-icon-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'maskable'
            }
          ],
          screenshots: [
            {
              src: 'img/desktop.png',
              sizes: '2054x1324',
              type: 'image/png',
              form_factor: 'wide',
              label: 'Desktop Gbajs3'
            },
            {
              src: 'img/mobile.png',
              sizes: '1170x2532',
              type: 'image/png',
              form_factor: 'narrow',
              label: 'Mobile Gbajs3'
            }
          ]
        },
        workbox: {
          globPatterns: ['**/*.{js,css,html,wasm}'],
          navigateFallbackDenylist: [/^\/admin/]
        },
        ...(withCOIServiceWorker
          ? {
              injectRegister: null,
              strategies: 'injectManifest',
              srcDir: 'src/service-worker',
              filename: 'coi-sw.ts',
              injectManifest: {
                injectionPoint: undefined
              }
            }
          : {})
      }),
      viteStaticCopy({
        targets: [
          {
            src: 'node_modules/@thenick775/mgba-wasm/dist/*.wasm.map',
            dest: 'assets'
          }
        ]
      }),
      visualizer({ gzipSize: true }) as PluginOption
    ],
    optimizeDeps: {
      exclude: ['@thenick775/mgba-wasm']
    },
    server: {
      headers: {
        'Cross-Origin-Embedder-Policy': 'require-corp',
        'Cross-Origin-Opener-Policy': 'same-origin'
      }
    },
    build: {
      sourcemap: true,
      rolldownOptions: {
        output: {
          codeSplitting: {
            groups: [
              {
                name: 'react',
                test: /node_modules[\\/](react|react-dom|scheduler)([\\/]|$)/
              },
              {
                name: 'emotion',
                test: /node_modules[\\/]@emotion[\\/](react|styled)([\\/]|$)/
              },
              {
                name: 'mui',
                test: /node_modules[\\/]@mui[\\/]material([\\/]|$)/
              },
              {
                name: 'mui-x',
                test: /node_modules[\\/]@mui[\\/]x-tree-view([\\/]|$)/
              },
              {
                name: 'mgba',
                test: /node_modules[\\/]@thenick775[\\/]mgba-wasm([\\/]|$)/
              },
              {
                name: 'onboarding',
                test: /node_modules[\\/]react-ios-pwa-prompt-ts([\\/]|$)/
              },
              {
                name: 'dnd',
                test: /node_modules[\\/](react-draggable|react-dropzone|react-rnd)([\\/]|$)/
              },
              {
                name: 'query',
                test: /node_modules[\\/](?:@tanstack|zod)([\\/]|$)/
              },
              {
                name: 'ui',
                test: /node_modules[\\/](react-modal|react-hot-toast|react-spinners|react-animate-height|react-icons|react-error-boundary)([\\/]|$)/
              },
              {
                name: 'hooks',
                test: /node_modules[\\/](react-hook-form|@uidotdev[\\/]usehooks|jwt-decode|nanoid)([\\/]|$)/
              },
              {
                name: 'zip',
                test: /node_modules[\\/]@zip\.js[\\/]zip\.js([\\/]|$)/
              }
            ]
          }
        }
      }
    },
    test: {
      globals: true,
      restoreMocks: true,
      environment: 'jsdom',
      setupFiles: ['./test/setup.ts'],
      coverage: {
        provider: 'v8',
        include: ['src'],
        reporter: ['html', 'json-summary', 'json'],
        exclude: [
          ...coverageConfigDefaults.exclude,
          'test/**',
          'src/emulator/mgba/wasm/**',
          '**/*.d.ts',
          '**/*eslint*',
          '**/service-worker/**',
          '**/.DS_Store'
        ]
      }
    }
  };
});
